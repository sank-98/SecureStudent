interface SystemArchitecture {
    frontend: {
        studentPortal: {
            features: string[];
            security: string[];
        };
        adminDashboard: {
            controls: string[];
            monitoring: string[];
        };
    };
    backend: {
        database: string;
        encryption: string;
        api: string;
        security: string[];
    };
    security: {
        authentication: string[];
        authorization: string[];
        monitoring: string[];
    };
}

const architecture: SystemArchitecture = {
    frontend: {
        studentPortal: {
            features: [
                "Personal data access",
                "Academic records view",
                "Security settings management"
            ],
            security: [
                "SSL/TLS encryption",
                "Session management",
                "Anti-XSS protection"
            ]
        },
        adminDashboard: {
            controls: [
                "User management",
                "Access control",
                "System configuration"
            ],
            monitoring: [
                "Real-time activity logs",
                "Security alerts",
                "Performance metrics"
            ]
        }
    },
    backend: {
        database: "PostgreSQL with encryption",
        encryption: "AES-256",
        api: "RESTful with JWT",
        security: [
            "Input validation",
            "Rate limiting",
            "SQL injection protection"
        ]
    },
    security: {
        authentication: [
            "Multi-factor authentication",
            "Password policies",
            "Account lockout"
        ],
        authorization: [
            "Role-based access control",
            "Permission management",
            "Access levels"
        ],
        monitoring: [
            "Intrusion detection",
            "Activity monitoring",
            "Audit logging"
        ]
    }
};